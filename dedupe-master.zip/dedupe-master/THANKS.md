# Thanks To

* Jon Markel for the Illinois campaign contributions data used in the mysql_example, which he got from 
  the [Illinois State Board of Elections](http://www.elections.il.gov/)

* [Daniel Müllner](http://math.stanford.edu/~muellner/) for his wonderful [fastcluster](http://math.stanford.edu/~muellner/fastcluster.html) library and the many changes he made at our request
