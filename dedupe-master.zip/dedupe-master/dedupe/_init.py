from dedupe.api import StaticDedupe, Dedupe
from dedupe.api import StaticRecordLink, RecordLink
from dedupe.api import StaticGazetteer, Gazetteer
from dedupe.convenience import consoleLabel, trainingDataDedupe, trainingDataLink, canonicalize
